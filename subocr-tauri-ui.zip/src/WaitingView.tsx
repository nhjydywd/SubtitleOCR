
import React from 'react';


const WaitingView: React.FC = () => {
  return (
    <div>
      <h1>Waiting for data...</h1>
    </div>
  );
}

export default WaitingView;