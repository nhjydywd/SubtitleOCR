
// export type SubtitleAnchor = { 
//     center_x: number, 
//     center_y: number, 
//     height: number, 
//     lang: number, 
//     is_primary: number, 
//     avg_width: number, 
//     min_width: number, 
//     mid_width: number, 
//     max_width: number, 
// };
// export type BoundingBox = {
//     center_x: number,
//     center_y: number,
//     width: number,
//     height: number,
// };
// export type CVColor = { 
//     r: number, 
//     g: number, 
//     b: number, 
// };


// export type SetVideoResponse = {
//     valid: boolean,
//     width: number,
//     height: number,
//     start_us: number,
//     duration_us: number,
// };